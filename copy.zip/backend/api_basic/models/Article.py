from distutils.command.upload import upload
from django.db import models

# Create your models here.
# def upload_to(instance, filename):
#     return 'images/{filename}'.format(filename=filename)

# class Article(models.Model):
#     image_url = models.ImageField(upload_to='media/', blank=True, null=True)

    # def __str__(self):
    #     return self.name + ": " + str(self.imagefile)
