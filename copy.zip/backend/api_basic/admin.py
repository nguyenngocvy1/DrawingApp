from django.contrib import admin
# from .models.Article import Article

# Register your models here.
# admin.site.register(Article)